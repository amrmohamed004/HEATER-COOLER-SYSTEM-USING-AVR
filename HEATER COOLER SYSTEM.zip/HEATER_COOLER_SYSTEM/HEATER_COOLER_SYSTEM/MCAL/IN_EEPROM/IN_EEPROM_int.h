

#ifndef MCAL_IN_EEPROM_IN_EEPROM_INT_H_
#define MCAL_IN_EEPROM_IN_EEPROM_INT_H_

void IN_EEPROM_voidReadDataByte (u16 Copy_u16Address, u8* Copy_u8Data);
void IN_EEPROM_voidWriteDataByte(u16 Copy_u16Address, u8  Copy_u8Data);


#endif /* MCAL_IN_EEPROM_IN_EEPROM_INT_H_ */
