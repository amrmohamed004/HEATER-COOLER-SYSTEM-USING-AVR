﻿/*
 * HEAT_COOL_INT.h
 *
 * Created: 09/07/2025 11:15:14 ص
 *  Author: 3mR
 */ 
void heat_cool_init();
void heat_on();
void heat_off();
void cool_on();
void cool_off();