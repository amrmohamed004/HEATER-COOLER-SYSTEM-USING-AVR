﻿
/*
 * HEAT_COOL_cfg.h
 *
 * Created: 12/07/2025 10:28:17 ص
 *  Author: 3mR
 */ 
#include "../../MCAL/DIO/DIO_int.h"


#define HEATER_PORT DIO_PORTC
#define HEATER_PIN DIO_PIN_0

#define COOLER_PORT DIO_PORTC
#define COOLER_PIN DIO_PIN_1