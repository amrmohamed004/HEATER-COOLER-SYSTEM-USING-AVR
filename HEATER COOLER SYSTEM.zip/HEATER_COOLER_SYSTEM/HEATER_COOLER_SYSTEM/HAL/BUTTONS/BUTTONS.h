﻿/*
 * BOTTONS.h
 *
 * Created: 09/07/2025 11:16:05 ص
 *  Author: 3mR
 */ 
#include "../../Service/Std_type.h"

void buttons_init() ;
u8 button_up_pressed();
u8 button_down_pressed();
u8 button_on_off_pressed(); 
