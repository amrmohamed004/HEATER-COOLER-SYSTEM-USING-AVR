

#ifndef HAL_CLCD_CLCD_PRV_H_
#define HAL_CLCD_CLCD_PRV_H_

/*mode */
#define CLCD_4_BIT   0
#define CLCD_8_BIT   1


#endif /* HAL_CLCD_CLCD_PRV_H_ */
