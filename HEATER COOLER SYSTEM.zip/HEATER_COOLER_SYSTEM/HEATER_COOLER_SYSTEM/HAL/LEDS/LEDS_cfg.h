﻿
/*
 * LEDS_cfg.h
 *
 * Created: 12/07/2025 10:27:45 ص
 *  Author: 3mR
 */ 
#include "../../MCAL/DIO/DIO_int.h"


#define RED_LED_PORT DIO_PORTD
#define RED_LED_PIN DIO_PIN_1
#define BLUE_LED_PORT DIO_PORTD
#define BLUE_LED_PIN DIO_PIN_2
