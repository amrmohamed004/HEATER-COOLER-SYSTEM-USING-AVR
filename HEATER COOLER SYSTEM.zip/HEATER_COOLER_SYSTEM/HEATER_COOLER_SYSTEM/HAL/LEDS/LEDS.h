﻿/*
 * LEDS.h
 *
 * Created: 09/07/2025 11:17:39 ص
 *  Author: 3mR
 */ 
void leds_init(void);
void red_led_on(void);
void red_led_off(void);
void blue_led_on(void);
void blue_led_off(void) ;