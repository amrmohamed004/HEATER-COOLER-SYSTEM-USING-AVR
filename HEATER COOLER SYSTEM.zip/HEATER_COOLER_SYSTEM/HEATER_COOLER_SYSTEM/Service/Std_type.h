


#ifndef STD_TYPE_H
#define STD_TYPE_H

typedef unsigned char           u8; /*Data type for 8 bits unsigned */
typedef unsigned short int      u16;/*Data type for 16 bits unsigned */
typedef unsigned long int       u32;/*Data type for 32 bits unsigned */
typedef unsigned long long int  u64;/*Data type for 64 bits unsigned */

typedef signed char             s8; /*Data type for 8 bits unsigned */
typedef signed short int        s16;/*Data type for 16 bits unsigned */
typedef signed long int         s32;/*Data type for 32 bits unsigned */
typedef signed long long int    s64;/*Data type for 64 bits unsigned */

typedef float                   f32;/*Data type for 32 bits float */
typedef double                  f64;/*Data type for 64 bits float */
#define NULL 					(void *)(0)
#endif
